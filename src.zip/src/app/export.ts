export interface info {
    "país Name": string
    "país Code": string
    "serie Name": string
    "serie Code": string
    "2020 [YR2020]": string
  }