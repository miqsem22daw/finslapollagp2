import { Component } from '@angular/core';
import { NgModule } from '@angular/core';

@Component({
    selector: 'aplicacio',
    template: `
    
    <router-outlet></router-outlet>
  `
})
export class Global {
}